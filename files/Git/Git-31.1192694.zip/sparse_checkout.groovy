/*
* Licensed Materials - Property of HCL
* UrbanCode Build
* (c) Copyright HCL Technologies Ltd. 2024. All Rights Reserved.
*
* Sparse checkout script for JAC pre-workflow - fetches only specified files
*/
import com.urbancode.air.*

//--------------------------------------------------------------------------------------------------
// Initialization
//--------------------------------------------------------------------------------------------------
final def workDir = new File('.').canonicalFile
final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def stepProps = apTool.getStepProperties();

//--------------------------------------------------------------------------------------------------
// Repository Properties
//--------------------------------------------------------------------------------------------------
final String scmCmd     = stepProps['source/repo/commandPath'] ?: 'git'
final String baseUrl    = stepProps['source/repo/repoBaseUrl']
final String username   = stepProps['source/repo/username']
final String password   = stepProps['source/repo/password'] ?: stepProps['source/repo/passScript']

//--------------------------------------------------------------------------------------------------
// Source Properties
//--------------------------------------------------------------------------------------------------
final String srcName            = stepProps['source'];
final File dir                  = new File(workDir, stepProps['source/dirOffset'] ?: '.').canonicalFile
final String remoteUrl          = stepProps['source/remoteUrl']
final String sourceBranch       = stepProps['source/branch'] ?: 'master'
final String remoteName         = stepProps['source/remoteName'] ?: 'origin'

//--------------------------------------------------------------------------------------------------
// Step Properties - Sparse Checkout specific
//--------------------------------------------------------------------------------------------------
// Files/patterns to checkout (comma-separated), defaults to BuildFile.json
final String sparsePatterns     = stepProps['sparsePatterns'] ?: 'BuildFile.json'
// Fallback branch to use when configured branch has unresolved properties
final String fallbackBranch     = stepProps['fallbackBranch']

//--------------------------------------------------------------------------------------------------
// Buildlife Properties
//--------------------------------------------------------------------------------------------------
final String blBranch   = stepProps["buildlife/workspace.branch.$srcName"]

//--------------------------------------------------------------------------------------------------
// Helper functions
//--------------------------------------------------------------------------------------------------
def runCommand(File workingDir, List<String> command, String description = null, int timeoutSeconds = 60) {
    if (description) {
        println "=== $description ==="
    }
    // Mask password in printed command
    def printCmd = command.collect { it.replaceFirst(~"^(https?://.*):(.*)@", '$1:****@') }
    println "Running: ${printCmd.join(' ')}"
    
    def processBuilder = new ProcessBuilder(command)
    processBuilder.directory(workingDir)
    processBuilder.redirectErrorStream(true)
    
    // Set environment to disable git prompts and set timeouts
    def env = processBuilder.environment()
    env.put('GIT_TERMINAL_PROMPT', '0')
    env.put('GIT_ASKPASS', '')
    // Set git HTTP timeout to 30 seconds
    env.put('GIT_HTTP_LOW_SPEED_LIMIT', '1000')
    env.put('GIT_HTTP_LOW_SPEED_TIME', '30')
    
    def process = processBuilder.start()
    def output = new StringBuilder()
    
    // Read output in a separate thread to prevent blocking
    def outputThread = Thread.start {
        process.inputStream.eachLine { line ->
            println line
            output.append(line).append('\n')
        }
    }
    
    // Wait with timeout
    def completed = process.waitFor(timeoutSeconds, java.util.concurrent.TimeUnit.SECONDS)
    if (!completed) {
        process.destroyForcibly()
        outputThread.interrupt()
        throw new RuntimeException("Command timed out after ${timeoutSeconds} seconds: ${printCmd.join(' ')}")
    }
    
    outputThread.join(5000) // Wait up to 5 seconds for output thread to finish
    
    def exitCode = process.exitValue()
    if (exitCode != 0) {
        throw new RuntimeException("Command failed with exit code $exitCode: ${printCmd.join(' ')}")
    }
    return output.toString().trim()
}

def calculateRepositoryUrl(String baseUrl, String remoteUrl, String username, String password) {
    if (!remoteUrl) {
        throw new IllegalArgumentException("Remote URL is required but was not provided. Make sure source configuration is set.")
    }
    def result = new URI(remoteUrl)
    if (baseUrl) {
        def prefixURI = new URI(baseUrl + "/")
        result = prefixURI.resolve(remoteUrl)
    }
    result = result.normalize()
    String repoUrl = result.toString()
    
    // Embed username and password credentials on remoteUrl for http(s)
    if (repoUrl.startsWith('http') && username) {
        def encodedUser = URLEncoder.encode(username, 'UTF-8')
        def encodedPass = password ? URLEncoder.encode(password, 'UTF-8') : ''
        def userInfo = encodedUser
        if (encodedPass) {
            userInfo += ":" + encodedPass
        }
        repoUrl = repoUrl.replaceFirst(~'^(https?://)(.*@)?', '$1' + userInfo + '@')
    }
    return repoUrl
}

def detectDefaultBranch(File workingDir, String gitCmd, String repositoryUrl, String remote) {
    try {
        workingDir.mkdirs()

        // Run git ls-remote to get all refs including HEAD
        def processBuilder = new ProcessBuilder([gitCmd, 'ls-remote', '--symref', repositoryUrl])
        processBuilder.directory(workingDir)
        processBuilder.redirectErrorStream(true)
        def env = processBuilder.environment()
        env.put('GIT_TERMINAL_PROMPT', '0')
        env.put('GIT_ASKPASS', '')
        def process = processBuilder.start()
        def output = new StringBuilder()
        process.inputStream.eachLine { line -> output.append(line).append('\n') }
        process.waitFor(30, java.util.concurrent.TimeUnit.SECONDS)

        def outputStr = output.toString()
        def lines = outputStr.split('\n')

        // Method 1: Parse symref line (e.g., "ref: refs/heads/main\tHEAD")
        def symrefMatcher = outputStr =~ /ref: refs\/heads\/(\S+)\s+HEAD/
        if (symrefMatcher.find()) {
            def defaultBranch = symrefMatcher.group(1)
            println "Detected default branch from remote (symref): ${defaultBranch}"
            return defaultBranch
        }

        // Method 2: Match HEAD SHA against branch refs
        String headSha = null
        def branchRefs = [:]
        for (line in lines) {
            def parts = line.trim().split(/\s+/)
            if (parts.length >= 2) {
                if (parts[1] == 'HEAD') {
                    headSha = parts[0]
                } else if (parts[1].startsWith('refs/heads/')) {
                    branchRefs[parts[1].replace('refs/heads/', '')] = parts[0]
                }
            }
        }

        if (headSha) {
            // Prefer 'main' or 'master' if they match HEAD
            for (preferred in ['main', 'master']) {
                if (branchRefs[preferred] == headSha) {
                    println "Detected default branch from remote (SHA match): ${preferred}"
                    return preferred
                }
            }
            // Otherwise use first matching branch
            for (entry in branchRefs) {
                if (entry.value == headSha) {
                    println "Detected default branch from remote (SHA match): ${entry.key}"
                    return entry.key
                }
            }
        }
    } catch (Exception e) {
        println "Could not detect default branch: ${e.message}"
    }
    println "Could not detect default branch, falling back to 'main'"
    return 'main'
}

//--------------------------------------------------------------------------------------------------
// Perform sparse checkout
//--------------------------------------------------------------------------------------------------
println "=== Git Sparse Checkout ==="
println "Working directory: ${dir.absolutePath}"
println "Sparse patterns: $sparsePatterns"

dir.mkdirs()

def cmdHelper = new CommandHelper(dir)
def repoUrl = calculateRepositoryUrl(baseUrl, remoteUrl, username, password)

// Determine the branch to use:
// 1. Use source config branch if resolved
// 2. Fall back to defaultBranch from JAC step if source branch is unresolved
// 3. Auto-detect remote default branch as last resort
def branch = blBranch ?: sourceBranch
if (branch == null || branch.isEmpty() || branch.contains('${') || branch.contains('p:') || branch.startsWith('\${')) {
    println "Source config branch '$branch' is not resolved"
    if (fallbackBranch != null && !fallbackBranch.isEmpty()) {
        println "Using default branch from JAC step: $fallbackBranch"
        branch = fallbackBranch
    } else {
        println "No default branch configured in JAC step - detecting from remote..."
        branch = detectDefaultBranch(dir, scmCmd, repoUrl, remoteName)
    }
}
println "Branch: $branch"

// Check if .git directory exists
def gitDir = new File(dir, '.git')
if (!gitDir.isDirectory()) {
    // Initialize new repository
    runCommand(dir, [scmCmd, 'init'], 'Git Init')
    
    // Add remote
    runCommand(dir, [scmCmd, 'remote', 'add', remoteName, repoUrl], 'Git Remote Add')
} else {
    // Update remote URL if repo exists
    runCommand(dir, [scmCmd, 'remote', 'set-url', remoteName, repoUrl], 'Git Remote Set-URL')
}

// Enable sparse checkout
runCommand(dir, [scmCmd, 'config', 'core.sparseCheckout', 'true'], 'Enable Sparse Checkout')

// Configure sparse-checkout patterns
def sparseCheckoutFile = new File(dir, '.git/info/sparse-checkout')
sparseCheckoutFile.parentFile.mkdirs()

// Write patterns to sparse-checkout file
def patterns = sparsePatterns.split(',').collect { it.trim() }
sparseCheckoutFile.text = patterns.join('\n') + '\n'
println "Sparse checkout patterns written to: ${sparseCheckoutFile.absolutePath}"
patterns.each { println "  - $it" }

// Fetch - if branch is null, fetch default branch from origin
try {
    if (branch) {
        runCommand(dir, [scmCmd, 'fetch', '--depth', '1', remoteName, branch], 'Git Fetch (Shallow)')
    } else {
        // Fetch without specifying branch - gets default branch
        runCommand(dir, [scmCmd, 'fetch', '--depth', '1', remoteName], 'Git Fetch (Shallow - Default Branch)')
    }
} catch (Exception e) {
    // If shallow fetch fails, try regular fetch
    println "Shallow fetch failed, trying regular fetch..."
    if (branch) {
        runCommand(dir, [scmCmd, 'fetch', remoteName, branch], 'Git Fetch')
    } else {
        runCommand(dir, [scmCmd, 'fetch', remoteName], 'Git Fetch (Default Branch)')
    }
}

// Checkout the branch
try {
    if (branch) {
        runCommand(dir, [scmCmd, 'checkout', branch], 'Git Checkout')
    } else {
        // Checkout FETCH_HEAD which points to the default branch
        runCommand(dir, [scmCmd, 'checkout', 'FETCH_HEAD'], 'Git Checkout (Default Branch)')
    }
} catch (Exception e) {
    // If checkout fails, try creating branch from remote
    if (branch) {
        runCommand(dir, [scmCmd, 'checkout', '-B', branch, "${remoteName}/${branch}"], 'Git Checkout (Create Branch)')
    } else {
        runCommand(dir, [scmCmd, 'checkout', '-B', 'default', 'FETCH_HEAD'], 'Git Checkout (Create Default Branch)')
    }
}

// Get the current revision and branch name
def revision = runCommand(dir, [scmCmd, 'rev-parse', '--verify', 'HEAD'], 'Get Revision')
def actualBranch = branch ?: runCommand(dir, [scmCmd, 'rev-parse', '--abbrev-ref', 'HEAD'], 'Get Branch Name')
println ""
println "Sparse checkout complete!"
println "Revision: $revision"
println "Branch: $actualBranch"

// Verify the files were checked out
println ""
println "Files checked out:"
patterns.each { pattern ->
    def file = new File(dir, pattern)
    if (file.exists()) {
        println "  OK $pattern (${file.length()} bytes)"
    } else {
        println "  MISSING $pattern (not found - may not exist in repository)"
    }
}

// Update buildlife properties
if (revision) {
    apTool.setOutputProperty("buildlife/workspace.revision.$srcName", revision)
}
if (branch) {
    apTool.setOutputProperty("buildlife/workspace.branch.$srcName", branch)
}
if (repoUrl) {
    def safeUrl = repoUrl.replaceFirst(~"^(https?://.*):(.*)@", '$1:****@')
    apTool.setOutputProperty("buildlife/workspace.remoteUrl.$srcName", safeUrl)
}

apTool.storeOutputProperties()
println ""
println "Sparse checkout completed successfully!"
