/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2012, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
/**
 *
 */
package com.urbancode.air.plugin.automation


/**
 * @author jwa
 *
 */
public enum FailMode {

    //**************************************************************************
    // CLASS
    //**************************************************************************
    WARN_ONLY,
    FAIL_FAST,
    FAIL_ON_NO_UPDATES,
    FAIL_ON_ANY_FAILURE;

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
}
